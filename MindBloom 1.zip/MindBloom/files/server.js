/**
 * MindBloom Backend — server.js
 * Run: node server.js
 */

require('dotenv').config();
const express  = require('express');
const cors     = require('cors');
const path     = require('path');

const { initDB } = require('./database');
const otpRoutes  = require('./routes/otp');
const authRoutes      = require('./routes/auth');
const userRoutes      = require('./routes/users');
const checkinRoutes   = require('./routes/checkins');
const journalRoutes   = require('./routes/journals');
const chatRoutes      = require('./routes/chats');

const app  = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(cors({
  origin: process.env.FRONTEND_URL || '*',   // tighten in production
  credentials: true,
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve the frontend HTML from this folder (optional convenience)
app.use(express.static(path.join(__dirname, 'public')));

// ── Routes ────────────────────────────────────────────────────────────────────
app.use('/api/auth',     authRoutes);
app.use('/api/otp',      otpRoutes);
app.use('/api/users',    userRoutes);
app.use('/api/checkins', checkinRoutes);
app.use('/api/journals', journalRoutes);
app.use('/api/chats',    chatRoutes);

// Health-check
app.get('/api/health', (_req, res) =>
  res.json({ status: 'ok', time: new Date().toISOString() })
);

// ── Bootstrap ─────────────────────────────────────────────────────────────────
initDB();   // create tables if they don't exist
app.listen(PORT, () =>
  console.log(`🌿 MindBloom server running on http://localhost:${PORT}`)
);
