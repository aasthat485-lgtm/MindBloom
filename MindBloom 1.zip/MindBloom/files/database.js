const path = require('path');
const fs = require('fs');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'mindbloom.db');

let _db = null;
let SQL = null;

function getDB() {
  if (!_db) throw new Error('DB not ready. Call initDB() first.');
  return _db;
}

async function initDB() {
  const initSqlJs = require('sql.js');
  SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    _db = new SQL.Database(fs.readFileSync(DB_PATH));
  } else {
    _db = new SQL.Database();
  }

  const originalPrepare = _db.prepare.bind(_db);

  _db.save = () => {
    fs.writeFileSync(DB_PATH, Buffer.from(_db.export()));
  };

  _db.prepare = (sql) => {
    return {
      run: (...args) => {
        _db.run(sql, args);
        _db.save();
        const result = _db.exec('SELECT last_insert_rowid() as id');
        return {
          lastInsertRowid: result[0]?.values?.[0]?.[0] || null,
          changes: _db.getRowsModified()
        };
      },

      get: (...args) => {
        const stmt = originalPrepare(sql);
        stmt.bind(args);
        const row = stmt.step() ? stmt.getAsObject() : null;
        stmt.free();
        return row;
      },

      all: (...args) => {
        const stmt = originalPrepare(sql);
        stmt.bind(args);
        const rows = [];
        while (stmt.step()) {
          rows.push(stmt.getAsObject());
        }
        stmt.free();
        return rows;
      }
    };
  };

  const tables = `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      age INTEGER,
      phone TEXT,
      pronouns TEXT,
      therapist TEXT,
      dark_mode INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      last_login DATETIME
    );

    CREATE TABLE IF NOT EXISTS login_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      logged_in DATETIME DEFAULT CURRENT_TIMESTAMP,
      ip TEXT,
      user_agent TEXT
    );

    CREATE TABLE IF NOT EXISTS checkins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      mood INTEGER,
      energy INTEGER,
      anxiety INTEGER,
      sleep INTEGER,
      note TEXT,
      tags TEXT,
      checked_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS journals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      title TEXT,
      body TEXT,
      mood_tag TEXT,
      word_count INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS chat_messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      role TEXT,
      content TEXT,
      risk_level TEXT,
      sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS otp_codes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL,
      otp TEXT NOT NULL,
      expires_at DATETIME NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    `;

  tables
    .split(';')
    .map(s => s.trim())
    .filter(Boolean)
    .forEach(sql => _db.run(sql));

  _db.save();
  console.log('✅ Database initialised:', DB_PATH);
}

module.exports = { initDB, getDB };
