/**
 * mindbloom-api.js
 * ─────────────────────────────────────────────────────────────────
 * Drop this <script> tag just before </body> in digital-therapist.html:
 *   <script src="mindbloom-api.js"></script>
 *
 * Then replace the three auth stubs in the HTML with the wired versions below.
 * ─────────────────────────────────────────────────────────────────
 */

// ── CONFIG ────────────────────────────────────────────────────────────────────
const API_BASE = 'http://localhost:3000/api';   // change to your server URL in prod

// ── TOKEN STORAGE ─────────────────────────────────────────────────────────────
const Auth = {
  getToken  : ()        => localStorage.getItem('mb_token'),
  setToken  : (t)       => localStorage.setItem('mb_token', t),
  clearToken: ()        => localStorage.removeItem('mb_token'),
  getUser   : ()        => JSON.parse(localStorage.getItem('mb_user') || 'null'),
  setUser   : (u)       => localStorage.setItem('mb_user', JSON.stringify(u)),
  clearUser : ()        => localStorage.removeItem('mb_user'),
  isLoggedIn: ()        => !!localStorage.getItem('mb_token'),
};

// ── BASE FETCH WRAPPER ────────────────────────────────────────────────────────
async function apiFetch(path, options = {}) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const token   = Auth.getToken();
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res  = await fetch(`${API_BASE}${path}`, { ...options, headers });
  const data = await res.json();

  if (!res.ok) {
    const msg = data.error || `Request failed (${res.status})`;
    throw new Error(msg);
  }
  return data;
}

// ── AUTH API ──────────────────────────────────────────────────────────────────
const AuthAPI = {
  async register(name, email, password) {
    const data = await apiFetch('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
    Auth.setToken(data.token);
    Auth.setUser(data.user);
    return data;
  },

  async login(email, password) {
    const data = await apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    Auth.setToken(data.token);
    Auth.setUser(data.user);
    return data;
  },

  async logout() {
    try { await apiFetch('/auth/logout', { method: 'POST' }); } catch (_) {}
    Auth.clearToken();
    Auth.clearUser();
  },

  async me() {
    return apiFetch('/auth/me');
  },
};

// ── CHECK-IN API ──────────────────────────────────────────────────────────────
const CheckinAPI = {
  save(mood, energy, anxiety, sleep, note, tags) {
    return apiFetch('/checkins', {
      method: 'POST',
      body: JSON.stringify({ mood, energy, anxiety, sleep, note, tags }),
    });
  },
  list(limit = 30, offset = 0) {
    return apiFetch(`/checkins?limit=${limit}&offset=${offset}`);
  },
  heatmap() {
    return apiFetch('/checkins/heatmap');
  },
};

// ── JOURNAL API ───────────────────────────────────────────────────────────────
const JournalAPI = {
  create(title, body, mood_tag) {
    return apiFetch('/journals', {
      method: 'POST',
      body: JSON.stringify({ title, body, mood_tag }),
    });
  },
  list(limit = 20, offset = 0) {
    return apiFetch(`/journals?limit=${limit}&offset=${offset}`);
  },
  get(id) {
    return apiFetch(`/journals/${id}`);
  },
  update(id, title, body, mood_tag) {
    return apiFetch(`/journals/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ title, body, mood_tag }),
    });
  },
  delete(id) {
    return apiFetch(`/journals/${id}`, { method: 'DELETE' });
  },
};

// ── CHAT API ──────────────────────────────────────────────────────────────────
const ChatAPI = {
  saveMessages(messages) {   // [{ role, content, risk_level? }]
    return apiFetch('/chats', {
      method: 'POST',
      body: JSON.stringify(messages),
    });
  },
  history(limit = 50) {
    return apiFetch(`/chats?limit=${limit}`);
  },
  clear() {
    return apiFetch('/chats', { method: 'DELETE' });
  },
};

// ── USER PROFILE API ──────────────────────────────────────────────────────────
const UserAPI = {
  updateProfile(fields) {   // { name, age, phone, pronouns, therapist, dark_mode }
    return apiFetch('/users/me', {
      method: 'PUT',
      body: JSON.stringify(fields),
    });
  },
  changePassword(current_password, new_password) {
    return apiFetch('/users/me/password', {
      method: 'PUT',
      body: JSON.stringify({ current_password, new_password }),
    });
  },
  loginHistory() {
    return apiFetch('/users/me/logins');
  },
};

// ═════════════════════════════════════════════════════════════════════════════
// REPLACE the three auth stubs in digital-therapist.html with these:
// ═════════════════════════════════════════════════════════════════════════════

/**
 * Called by: <button onclick="doLogin()">Sign In →</button>
 * Replaces the original doLogin() stub.
 */
async function doLogin() {
  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  if (!email || !password) {
    showToast('⚠️ Please enter your email and password.');
    return;
  }

  const btn = document.querySelector('#login-form .btn-primary');
  btn.textContent = 'Signing in…';
  btn.disabled    = true;

  try {
    const { user } = await AuthAPI.login(email, password);
    APP_STATE.user.name = user.name.split(' ')[0];

    document.getElementById('auth-page').classList.remove('active');
    document.getElementById('app-page').classList.add('active');
    document.getElementById('sos-btn').style.display = 'flex';

    initApp(user);
    showToast(`👋 Welcome back, ${APP_STATE.user.name}!`);

    // Load persisted data
    loadUserData();
  } catch (err) {
    showToast(`❌ ${err.message}`);
  } finally {
    btn.textContent = 'Sign In →';
    btn.disabled    = false;
  }
}

/**
 * Called by: <button onclick="doSignup()">Create Account →</button>
 * Replaces the original doSignup() stub.
 */
async function doSignup() {
  const name     = document.getElementById('signup-name').value.trim();
  const email    = document.getElementById('signup-email').value.trim();
  const password = document.getElementById('signup-pass').value;

  if (!name || !email || !password) {
    showToast('⚠️ Please fill all signup fields.');
    return;
  }

  try {
    // STEP 1: send OTP
    await apiFetch('/otp/send', {
      method: 'POST',
      body: JSON.stringify({ email })
    });

    showToast('📩 OTP sent to your Gmail');

    // STEP 2: ask user OTP
    const otp = prompt('Enter the OTP sent to your email:');
    if (!otp) {
      showToast('⚠️ OTP entry cancelled');
      return;
    }

    // STEP 3: verify OTP
    const verify = await apiFetch('/otp/verify-signup', {
      method: 'POST',
      body: JSON.stringify({ email, otp })
    });

    if (!verify.success) {
      showToast('❌ Invalid OTP');
      return;
    }

    // STEP 4: create account finally
    const { user } = await AuthAPI.register(name, email, password);

    APP_STATE.user.name = user.name.split(' ')[0];

    document.getElementById('auth-page').classList.remove('active');
    document.getElementById('app-page').classList.add('active');
    document.getElementById('sos-btn').style.display = 'flex';

    initApp(user);
    showToast(`🌿 Welcome to MindBloom, ${APP_STATE.user.name}!`);
  } catch (err) {
    showToast(`❌ ${err.message}`);
  }
}

/**
 * Called by: <button onclick="doLogout()">Sign Out</button>
 * Replaces the original doLogout() stub.
 */
async function doLogout() {
  await AuthAPI.logout();
  document.getElementById('app-page').classList.remove('active');
  document.getElementById('auth-page').classList.add('active');
  document.getElementById('sos-btn').style.display = 'none';
  closeAmbient();
}

// ═════════════════════════════════════════════════════════════════════════════
// ENHANCED initApp — accepts the real user object from the API
// ═════════════════════════════════════════════════════════════════════════════
function initApp(user) {
  const n = APP_STATE.user.name;

  document.getElementById('greeting-name').textContent      = n;
  document.getElementById('sidebar-name').textContent       = n;
  document.getElementById('sidebar-avatar').textContent     = n[0].toUpperCase();
  document.getElementById('profile-avatar-big').textContent = n[0].toUpperCase();
  document.getElementById('profile-display-name').textContent = user?.name || n;
  document.getElementById('pf-name').value = user?.name || n;

  if (user?.email) {
    const emailEl = document.getElementById('pf-email');
    if (emailEl) emailEl.value = user.email;
  }

  const now  = new Date();
  const opts = { weekday: 'long', month: 'long', day: 'numeric' };
  document.getElementById('today-tag').textContent =
    now.toLocaleDateString('en-US', opts);
  document.getElementById('checkin-time').textContent =
    now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  document.getElementById('journal-date-meta').textContent =
    now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }) +
    ' · ' + now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

  const hour = now.getHours();
  const greeting =
    hour < 12 ? 'Good morning' :
    hour < 17 ? 'Good afternoon' : 'Good evening';
  document.getElementById('time-greeting').textContent = greeting;

  buildDashChart();
  buildStressChart();
  buildEnergyChart();
  buildHeatmap();
  buildJournalList();
  buildSoundList();
  buildNearbyList();
  showNudge('🌿 Take a deep breath. You\'ve got this.');
}

// ═════════════════════════════════════════════════════════════════════════════
// LOAD PERSISTED USER DATA (heatmap, journals, chat history)
// ═════════════════════════════════════════════════════════════════════════════
async function loadUserData() {
  // 1. Heatmap — replace static mock with real data
  try {
    const heatmapData = await CheckinAPI.heatmap();
    const grid = document.getElementById('heatmap-grid');
    grid.innerHTML = '';
    heatmapData.forEach(({ date, mood }) => {
      const cell = document.createElement('div');
      cell.className = `heatmap-cell mood-${mood}`;
      const tt  = document.createElement('div');
      tt.className  = 'heatmap-tooltip';
      tt.textContent = `${date} · Mood: ${['No data','Very Low','Low','Neutral','Good','Great'][mood] || 'No data'}`;
      cell.appendChild(tt);
      grid.appendChild(cell);
    });
  } catch (_) { /* fall back to static heatmap already rendered */ }

  // 2. Journals — replace mock entries with real ones
  try {
    const entries = await JournalAPI.list();
    if (entries.length > 0) {
      APP_STATE.journalEntries = entries.map(e => ({
        id    : e.id,
        title : e.title,
        date  : new Date(e.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
        text  : e.body || e.preview || '',
        mood  : e.mood_tag || '😐',
      }));
      buildJournalList();
    }
  } catch (_) {}

  // 3. Chat history — restore previous conversation
  try {
    const messages = await ChatAPI.history(50);
    const container = document.getElementById('chat-messages');
    // Only restore if the container has only the initial bot greeting
    if (messages.length > 0 && container.querySelectorAll('.message').length <= 1) {
      messages.forEach(m => appendChatMessage(m.role, m.content));
    }
  } catch (_) {}
}

// ═════════════════════════════════════════════════════════════════════════════
// WIRED-UP submitCheckin — saves real check-in to the database
// Replaces the original submitCheckin() stub.
// ═════════════════════════════════════════════════════════════════════════════
async function submitCheckin() {
  const mood    = selectedMoodEmoji;
  const energy  = Number(document.getElementById('energy-slider')?.value)  || null;
  const anxiety = Number(document.getElementById('anxiety-slider')?.value) || null;
  const sleep   = Number(document.getElementById('sleep-slider')?.value)   || null;
  const note    = document.getElementById('checkin-note')?.value           || null;

  try {
    await CheckinAPI.save(mood, energy, anxiety, sleep, note, []);
    showToast('✅ Check-in saved!');
  } catch (err) {
    showToast('⚠️ Could not save check-in: ' + err.message);
  }

  // Update UI (same as before)
  document.getElementById('checkin-success').style.display = 'block';
  document.querySelector('.checkin-card > .card').style.opacity = '0.5';
  document.querySelector('.checkin-card > .card').style.pointerEvents = 'none';
  document.querySelector('.nav-badge')?.remove();

  const cells = document.querySelectorAll('.heatmap-cell');
  if (cells.length > 0) {
    const last = cells[cells.length - 1];
    last.className = `heatmap-cell mood-${mood}`;
    const tt = last.querySelector('.heatmap-tooltip');
    if (tt) tt.textContent = 'Today · Mood: ' +
      ['', 'Very Low', 'Low', 'Neutral', 'Good', 'Great'][mood];
  }
}

// ═════════════════════════════════════════════════════════════════════════════
// WIRED-UP saveJournalEntry — persists to the database
// Replaces the original saveJournalEntry() stub.
// ═════════════════════════════════════════════════════════════════════════════
async function saveJournalEntry() {
  const e = APP_STATE.journalEntries.find(j => j.id === APP_STATE.currentJournal);
  if (!e) return;

  e.title = document.getElementById('journal-title').value;
  e.text  = document.getElementById('journal-textarea').value;

  try {
    if (typeof e.id === 'number' && e.id > 1000000000000) {
      // Newly created (Date.now() id) — create on server
      const saved = await JournalAPI.create(e.title, e.text, e.mood || null);
      e.id = saved.id;   // replace temp id with real DB id
    } else {
      await JournalAPI.update(e.id, e.title, e.text, e.mood || null);
    }
    showToast('📓 Journal saved!');
  } catch (err) {
    showToast('⚠️ Could not save journal: ' + err.message);
  }

  buildJournalList();
}

// ═════════════════════════════════════════════════════════════════════════════
// WIRED-UP saveProfile — persists to the database
// Replaces the original saveProfile() stub.
// ═════════════════════════════════════════════════════════════════════════════
async function saveProfile() {
  const name = document.getElementById('pf-name').value;
  const age  = document.getElementById('pf-age')?.value  || null;
  const ph   = document.getElementById('pf-phone')?.value || null;

  try {
    await UserAPI.updateProfile({ name, age, phone: ph });
    showToast('✅ Profile saved!');
  } catch (err) {
    showToast('⚠️ Could not save profile: ' + err.message);
  }

  // Update UI
  const first = name.split(' ')[0];
  APP_STATE.user.name = first;
  document.getElementById('greeting-name').textContent       = first;
  document.getElementById('sidebar-name').textContent        = first;
  document.getElementById('sidebar-avatar').textContent      = first[0].toUpperCase();
  document.getElementById('profile-avatar-big').textContent  = first[0].toUpperCase();
  document.getElementById('profile-display-name').textContent = name;
}

// ═════════════════════════════════════════════════════════════════════════════
// WIRED-UP chat — saves messages to DB after each exchange
// Add this helper call inside the existing sendChatMessage() after botReply is shown
// ═════════════════════════════════════════════════════════════════════════════
async function persistChatExchange(userText, botText, riskLevel) {
  try {
    await ChatAPI.saveMessages([
      { role: 'user', content: userText,  risk_level: riskLevel },
      { role: 'bot',  content: botText,   risk_level: riskLevel },
    ]);
  } catch (_) { /* non-critical */ }
}

// ═════════════════════════════════════════════════════════════════════════════
// AUTO-LOGIN — restore session on page load
// ═════════════════════════════════════════════════════════════════════════════
(async function autoLogin() {
  if (!Auth.isLoggedIn()) return;

  try {
    const user = await AuthAPI.me();
    Auth.setUser(user);
    APP_STATE.user.name = user.name.split(' ')[0];

    document.getElementById('auth-page').classList.remove('active');
    document.getElementById('app-page').classList.add('active');
    document.getElementById('sos-btn').style.display = 'flex';

    initApp(user);
    loadUserData();
  } catch (_) {
    // Token expired or invalid — clear and show login
    Auth.clearToken();
    Auth.clearUser();
  }
})();
