/**
 * routes/auth.js
 * POST /api/auth/register  — create account
 * POST /api/auth/login     — returns JWT + user object
 * POST /api/auth/logout    — (client-side; logged server-side for audit)
 */

const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { getDB }        = require('../db/database');
const { authenticate, JWT_SECRET } = require('../middleware/auth');

const TOKEN_TTL = '7d';   // token lifespan

// ── REGISTER ──────────────────────────────────────────────────────────────────
router.post('/register', async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ error: 'name, email and password are required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }

  try {
    const db   = getDB();
    const hash = await bcrypt.hash(password, 12);

    const stmt = db.prepare(
      `INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)`
    );
    const result = stmt.run(name.trim(), email.trim().toLowerCase(), hash);

    const user = db.prepare(`SELECT id, name, email, created_at FROM users WHERE id = ?`)
                   .get(result.lastInsertRowid);

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      JWT_SECRET,
      { expiresIn: TOKEN_TTL }
    );

    return res.status(201).json({ token, user });
  } catch (err) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      return res.status(409).json({ error: 'An account with that email already exists.' });
    }
    console.error('[register]', err);
    return res.status(500).json({ error: 'Registration failed. Please try again.' });
  }
});

// ── LOGIN ─────────────────────────────────────────────────────────────────────
router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'email and password are required.' });
  }

  try {
    const db   = getDB();
    const user = db.prepare(`SELECT * FROM users WHERE email = ?`)
                   .get(email.trim().toLowerCase());

    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Update last_login timestamp
    db.prepare(`UPDATE users SET last_login = datetime('now') WHERE id = ?`).run(user.id);

    // Record login event
    db.prepare(
      `INSERT INTO login_log (user_id, ip, user_agent) VALUES (?, ?, ?)`
    ).run(user.id, req.ip, req.headers['user-agent'] || '');

    const token = jwt.sign(
      { id: user.id, email: user.email, name: user.name },
      JWT_SECRET,
      { expiresIn: TOKEN_TTL }
    );

    // Return safe user object (no password hash)
    const safeUser = {
      id:         user.id,
      name:       user.name,
      email:      user.email,
      age:        user.age,
      phone:      user.phone,
      pronouns:   user.pronouns,
      therapist:  user.therapist,
      dark_mode:  user.dark_mode === 1,
      created_at: user.created_at,
      last_login: user.last_login,
    };

    return res.json({ token, user: safeUser });
  } catch (err) {
    console.error('[login]', err);
    return res.status(500).json({ error: 'Login failed. Please try again.' });
  }
});

// ── LOGOUT (audit log) ────────────────────────────────────────────────────────
router.post('/logout', authenticate, (req, res) => {
  // JWT is stateless; just return success so the client can clear its token.
  // Add token to a blocklist here if you need immediate invalidation.
  return res.json({ message: 'Logged out successfully.' });
});

// ── VALIDATE TOKEN ────────────────────────────────────────────────────────────
router.get('/me', authenticate, (req, res) => {
  const db   = getDB();
  const user = db.prepare(
    `SELECT id, name, email, age, phone, pronouns, therapist, dark_mode, created_at, last_login
     FROM users WHERE id = ?`
  ).get(req.user.id);

  if (!user) return res.status(404).json({ error: 'User not found.' });

  return res.json({ ...user, dark_mode: user.dark_mode === 1 });
});

module.exports = router;
