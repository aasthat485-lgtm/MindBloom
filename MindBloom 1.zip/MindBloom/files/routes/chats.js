/**
 * routes/chats.js
 * POST /api/chats          — save a message pair (user + bot response)
 * GET  /api/chats          — fetch conversation history (newest first)
 * DELETE /api/chats        — clear all chat history for the user
 */

const router = require('express').Router();
const { getDB } = require('../database');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

// ── SAVE MESSAGE(S) ───────────────────────────────────────────────────────────
// Accepts: { role, content, risk_level }
// OR an array: [{ role, content }, { role, content }]
router.post('/', (req, res) => {
  const db   = getDB();
  const msgs = Array.isArray(req.body) ? req.body : [req.body];

  const insert = db.prepare(
    `INSERT INTO chat_messages (user_id, role, content, risk_level)
     VALUES (?, ?, ?, ?)`
  );

  const insertMany = db.transaction((messages) => {
    for (const m of messages) {
      if (!m.role || !m.content) continue;
      insert.run(req.user.id, m.role, m.content, m.risk_level || null);
    }
  });

  insertMany(msgs);
  return res.status(201).json({ saved: msgs.length });
});

// ── GET HISTORY ───────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const limit  = Math.min(Number(req.query.limit)  || 50, 200);
  const offset = Number(req.query.offset) || 0;

  const db   = getDB();
  const rows = db.prepare(
    `SELECT id, role, content, risk_level, sent_at
     FROM chat_messages WHERE user_id = ?
     ORDER BY sent_at ASC LIMIT ? OFFSET ?`
  ).all(req.user.id, limit, offset);

  return res.json(rows);
});

// ── CLEAR HISTORY ─────────────────────────────────────────────────────────────
router.delete('/', (req, res) => {
  const db = getDB();
  const { changes } = db.prepare(`DELETE FROM chat_messages WHERE user_id = ?`).run(req.user.id);
  return res.json({ deleted: changes });
});

module.exports = router;
