/**
 * routes/checkins.js
 * POST /api/checkins          — save a daily check-in
 * GET  /api/checkins          — list all check-ins (newest first)
 * GET  /api/checkins/heatmap  — compact mood array for the last 90 days
 * GET  /api/checkins/:id      — single check-in
 * DELETE /api/checkins/:id    — remove a check-in
 */

const router = require('express').Router();
const { getDB } = require('../database');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

// ── CREATE CHECK-IN ───────────────────────────────────────────────────────────
router.post('/', (req, res) => {
  const { mood, energy, anxiety, sleep, note, tags } = req.body;

  if (!mood || mood < 1 || mood > 5) {
    return res.status(400).json({ error: 'mood must be 1–5.' });
  }

  const db     = getDB();
  const result = db.prepare(
    `INSERT INTO checkins (user_id, mood, energy, anxiety, sleep, note, tags)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).run(
    req.user.id,
    mood,
    energy  ?? null,
    anxiety ?? null,
    sleep   ?? null,
    note    || null,
    tags    ? JSON.stringify(tags) : null
  );

  const row = db.prepare(`SELECT * FROM checkins WHERE id = ?`).get(result.lastInsertRowid);
  return res.status(201).json(parseCheckin(row));
});

// ── LIST CHECK-INS ────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const limit  = Math.min(Number(req.query.limit)  || 30, 200);
  const offset = Number(req.query.offset) || 0;

  const db   = getDB();
  const rows = db.prepare(
    `SELECT * FROM checkins WHERE user_id = ?
     ORDER BY checked_at DESC LIMIT ? OFFSET ?`
  ).all(req.user.id, limit, offset);

  return res.json(rows.map(parseCheckin));
});

// ── HEATMAP (last 90 days) ────────────────────────────────────────────────────
router.get('/heatmap', (req, res) => {
  const db   = getDB();
  const rows = db.prepare(
    `SELECT date(checked_at) AS day, AVG(mood) AS avg_mood
     FROM checkins
     WHERE user_id = ? AND checked_at >= date('now', '-90 days')
     GROUP BY day
     ORDER BY day ASC`
  ).all(req.user.id);

  // Build a Map keyed by ISO date string
  const map = {};
  rows.forEach(r => { map[r.day] = Math.round(r.avg_mood); });

  // Fill every day in the window
  const result = [];
  for (let i = 89; i >= 0; i--) {
    const d   = new Date();
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    result.push({ date: key, mood: map[key] ?? 0 });
  }

  return res.json(result);
});

// ── SINGLE CHECK-IN ───────────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const db  = getDB();
  const row = db.prepare(`SELECT * FROM checkins WHERE id = ? AND user_id = ?`)
                .get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'Check-in not found.' });
  return res.json(parseCheckin(row));
});

// ── DELETE CHECK-IN ───────────────────────────────────────────────────────────
router.delete('/:id', (req, res) => {
  const db = getDB();
  const changes = db.prepare(`DELETE FROM checkins WHERE id = ? AND user_id = ?`)
                    .run(req.params.id, req.user.id).changes;
  if (!changes) return res.status(404).json({ error: 'Check-in not found.' });
  return res.json({ message: 'Deleted.' });
});

// ── helper ────────────────────────────────────────────────────────────────────
function parseCheckin(row) {
  return { ...row, tags: row.tags ? JSON.parse(row.tags) : [] };
}

module.exports = router;
