/**
 * routes/journals.js
 * POST   /api/journals       — create entry
 * GET    /api/journals       — list entries (newest first)
 * GET    /api/journals/:id   — single entry
 * PUT    /api/journals/:id   — update entry
 * DELETE /api/journals/:id   — delete entry
 */

const router = require('express').Router();
const { getDB } = require('../database');
const { authenticate } = require('../middleware/auth');

router.use(authenticate);

// ── CREATE ────────────────────────────────────────────────────────────────────
router.post('/', (req, res) => {
  const { title = 'Untitled', body = '', mood_tag } = req.body;
  const word_count = body.trim().split(/\s+/).filter(Boolean).length;

  const db     = getDB();
  const result = db.prepare(
    `INSERT INTO journals (user_id, title, body, mood_tag, word_count)
     VALUES (?, ?, ?, ?, ?)`
  ).run(req.user.id, title.trim(), body, mood_tag || null, word_count);

  const row = db.prepare(`SELECT * FROM journals WHERE id = ?`).get(result.lastInsertRowid);
  return res.status(201).json(row);
});

// ── LIST ──────────────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const limit  = Math.min(Number(req.query.limit)  || 20, 100);
  const offset = Number(req.query.offset) || 0;

  const db   = getDB();
  const rows = db.prepare(
    `SELECT id, title, mood_tag, word_count, created_at, updated_at,
            substr(body, 1, 120) AS preview
     FROM journals WHERE user_id = ?
     ORDER BY updated_at DESC LIMIT ? OFFSET ?`
  ).all(req.user.id, limit, offset);

  return res.json(rows);
});

// ── SINGLE ────────────────────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const db  = getDB();
  const row = db.prepare(`SELECT * FROM journals WHERE id = ? AND user_id = ?`)
                .get(req.params.id, req.user.id);
  if (!row) return res.status(404).json({ error: 'Journal entry not found.' });
  return res.json(row);
});

// ── UPDATE ────────────────────────────────────────────────────────────────────
router.put('/:id', (req, res) => {
  const { title, body, mood_tag } = req.body;
  const db = getDB();

  const existing = db.prepare(`SELECT * FROM journals WHERE id = ? AND user_id = ?`)
                     .get(req.params.id, req.user.id);
  if (!existing) return res.status(404).json({ error: 'Journal entry not found.' });

  const newTitle     = title    !== undefined ? title.trim() : existing.title;
  const newBody      = body     !== undefined ? body         : existing.body;
  const newMoodTag   = mood_tag !== undefined ? mood_tag     : existing.mood_tag;
  const newWordCount = newBody.trim().split(/\s+/).filter(Boolean).length;

  db.prepare(
    `UPDATE journals
     SET title = ?, body = ?, mood_tag = ?, word_count = ?, updated_at = datetime('now')
     WHERE id = ? AND user_id = ?`
  ).run(newTitle, newBody, newMoodTag, newWordCount, req.params.id, req.user.id);

  const updated = db.prepare(`SELECT * FROM journals WHERE id = ?`).get(req.params.id);
  return res.json(updated);
});

// ── DELETE ────────────────────────────────────────────────────────────────────
router.delete('/:id', (req, res) => {
  const db      = getDB();
  const changes = db.prepare(`DELETE FROM journals WHERE id = ? AND user_id = ?`)
                    .run(req.params.id, req.user.id).changes;
  if (!changes) return res.status(404).json({ error: 'Journal entry not found.' });
  return res.json({ message: 'Deleted.' });
});

module.exports = router;
