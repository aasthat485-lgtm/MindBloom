/**
 * routes/users.js
 * GET  /api/users/me           — fetch own profile
 * PUT  /api/users/me           — update profile fields
 * PUT  /api/users/me/password  — change password
 * GET  /api/users/me/logins    — login history
 * DELETE /api/users/me         — delete account
 */

const router = require('express').Router();
const bcrypt = require('bcryptjs');
const { getDB } = require('../database');
const { authenticate } = require('../middleware/auth');
// All routes require authentication
router.use(authenticate);

// ── GET PROFILE ───────────────────────────────────────────────────────────────
router.get('/me', (req, res) => {
  const db   = getDB();
  const user = db.prepare(
    `SELECT id, name, email, age, phone, pronouns, therapist, dark_mode, created_at, last_login
     FROM users WHERE id = ?`
  ).get(req.user.id);

  if (!user) return res.status(404).json({ error: 'User not found.' });
  return res.json({ ...user, dark_mode: user.dark_mode === 1 });
});

// ── UPDATE PROFILE ────────────────────────────────────────────────────────────
router.put('/me', (req, res) => {
  const { name, age, phone, pronouns, therapist, dark_mode } = req.body;
  const db = getDB();

  const fields = [];
  const values = [];

  if (name      !== undefined) { fields.push('name = ?');      values.push(name.trim()); }
  if (age       !== undefined) { fields.push('age = ?');       values.push(Number(age) || null); }
  if (phone     !== undefined) { fields.push('phone = ?');     values.push(phone); }
  if (pronouns  !== undefined) { fields.push('pronouns = ?'); values.push(pronouns); }
  if (therapist !== undefined) { fields.push('therapist = ?'); values.push(therapist); }
  if (dark_mode !== undefined) { fields.push('dark_mode = ?'); values.push(dark_mode ? 1 : 0); }

  if (fields.length === 0) {
    return res.status(400).json({ error: 'No fields provided to update.' });
  }

  values.push(req.user.id);
  db.prepare(`UPDATE users SET ${fields.join(', ')} WHERE id = ?`).run(...values);

  const updated = db.prepare(
    `SELECT id, name, email, age, phone, pronouns, therapist, dark_mode, created_at, last_login
     FROM users WHERE id = ?`
  ).get(req.user.id);

  return res.json({ ...updated, dark_mode: updated.dark_mode === 1 });
});

// ── CHANGE PASSWORD ───────────────────────────────────────────────────────────
router.put('/me/password', async (req, res) => {
  const { current_password, new_password } = req.body;

  if (!current_password || !new_password) {
    return res.status(400).json({ error: 'current_password and new_password are required.' });
  }
  if (new_password.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters.' });
  }

  const db   = getDB();
  const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(req.user.id);
  const match = await bcrypt.compare(current_password, user.password_hash);

  if (!match) return res.status(401).json({ error: 'Current password is incorrect.' });

  const hash = await bcrypt.hash(new_password, 12);
  db.prepare(`UPDATE users SET password_hash = ? WHERE id = ?`).run(hash, req.user.id);

  return res.json({ message: 'Password updated successfully.' });
});

// ── LOGIN HISTORY ─────────────────────────────────────────────────────────────
router.get('/me/logins', (req, res) => {
  const db   = getDB();
  const rows = db.prepare(
    `SELECT id, logged_in, ip, user_agent FROM login_log
     WHERE user_id = ? ORDER BY logged_in DESC LIMIT 50`
  ).all(req.user.id);

  return res.json(rows);
});

// ── DELETE ACCOUNT ────────────────────────────────────────────────────────────
router.delete('/me', async (req, res) => {
  const { password } = req.body;
  if (!password) return res.status(400).json({ error: 'Password required to delete account.' });

  const db   = getDB();
  const user = db.prepare(`SELECT * FROM users WHERE id = ?`).get(req.user.id);
  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) return res.status(401).json({ error: 'Incorrect password.' });

  db.prepare(`DELETE FROM users WHERE id = ?`).run(req.user.id);
  return res.json({ message: 'Account deleted.' });
});

module.exports = router;
