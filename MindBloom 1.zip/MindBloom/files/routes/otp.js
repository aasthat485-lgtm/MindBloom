const router = require('express').Router();
const nodemailer = require('nodemailer');
const bcrypt = require('bcryptjs');
const { getDB } = require('../database');

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// SEND OTP
router.post('/send', async (req, res) => {
  try {
    const { email } = req.body;
    const db = getDB();

   const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);

if (user) {
  return res.status(400).json({ error: 'Email already registered' });
}

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expires = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    db.prepare('DELETE FROM otp_codes WHERE email = ?').run(email);
    db.prepare(
      'INSERT INTO otp_codes (email, otp, expires_at) VALUES (?, ?, ?)'
    ).run(email, otp, expires);

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'MindBloom OTP',
      text: `Your OTP is ${otp}. Valid for 5 minutes.`
    });

    res.json({ message: 'OTP sent successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// VERIFY OTP
router.post('/verify-signup', async (req, res) => {
  try {
    const { email, otp } = req.body;
    const db = getDB();

    const record = db.prepare(
      'SELECT * FROM otp_codes WHERE email = ? AND otp = ?'
    ).get(email, otp);

    if (!record) {
      return res.status(400).json({ error: 'Invalid OTP', success: false });
    }

    if (new Date(record.expires_at) < new Date()) {
      return res.status(400).json({ error: 'OTP expired', success: false });
    }

    db.prepare('DELETE FROM otp_codes WHERE email = ?').run(email);

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;